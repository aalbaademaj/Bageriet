namespace Dagnysbageri.api.ViewModels;

public class ProductPostViewModel
{
    public string ItemNumber { get; set; }
    public string ProductName { get; set; }
    public string Description { get; set; }
    public double PriceKg { get; set; }

}
